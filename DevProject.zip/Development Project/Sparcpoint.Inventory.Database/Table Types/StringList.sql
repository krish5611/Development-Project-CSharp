﻿CREATE TYPE [dbo].[StringList] AS TABLE
(
	[Value] VARCHAR(512) NOT NULL
)
