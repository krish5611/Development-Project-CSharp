﻿using Sparcpoint.Data.DataAccess;
using Sparcpoint.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sparcpoint.Data.Contracts
{
    public interface IRepository<T> where T : class
    {
        List<T> GetAll();
        List<T> GetProductByGeneral(string param);
        void Add(T entity);
        void Update(T entity);
        void Delete(T entity);
    }
}


