﻿using System;
using System.Collections.Generic;
using System.Linq;
using Sparcpoint.Data.Contracts;
using Sparcpoint.Data.Models;

namespace Sparcpoint.Data.DataAccess
{
    public class ProductRepository<T> : IRepository<T> where T : Product
    {       
        private List<T> products;

        public ProductRepository()
        {                       
            products = new List<T>();            
        }

        public virtual List<T> GetAll()
        {            
            return products.ToList();
        }
        
        public virtual T GetById(int id)
        {
            return products.FirstOrDefault(p => p.ID == id);                     
        }

        public virtual List<T> GetProductByGeneral(string param)
        {
            return products.Where(p => p.ID.ToString() == param || p.Name.Contains(param) || p.Description.Contains(param)).ToList<T>();
        }

        public virtual void Add(T entity)
        {
            Insert(entity);
        }

        public virtual void Update(T entity)
        {

            if (entity != null)
            {
                entity.UpdateDate = DateTime.UtcNow;
            }

            products.Remove(entity as T);
            Insert(entity as T);                       
        }

        public virtual void Delete(T entity)
        {
            products.Remove(entity);
        }

        private void Insert(T entity)
        {

            if (entity != null)
            {
                entity.CreateDate = DateTime.UtcNow;
            }

            products.Add(entity as T);
        }
    }
}