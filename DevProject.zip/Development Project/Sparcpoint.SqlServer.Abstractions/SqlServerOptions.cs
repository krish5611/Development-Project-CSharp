﻿namespace Sparcpoint.SqlServer.Abstractions
{
    public class SqlServerOptions
    {
        public string ConnectionString { get; set; }
    }
}
