Implemented feature to get all inventory products and add a new product
Implemented repository pattern to enable loosely coupled and testable system
Used Swagger API to easily invoke API endpoints