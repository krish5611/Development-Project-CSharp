﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using Sparcpoint.Data.Contracts;
using Sparcpoint.Data.Models;

namespace Interview.Web.Controllers
{
    [Route("api/v1/products")]
    public class ProductController : Controller
    {
        private readonly IRepository<Product> _repository;

        public ProductController(IRepository<Product> repository)
        {
            this._repository = repository;
        }

        /// <summary>
        /// action method to get all products
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public Task<IActionResult> GetAllProducts()
        {
            var products = this._repository.GetAll();

            return Task.FromResult((IActionResult)Ok(products));
        }

        /// <summary>
        /// action method to get products by name/description
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public Task<IActionResult> GetProduct(string param)
        {
            IList<Product> result = new List<Product>();
            var products = this._repository.GetProductByGeneral(param);

            return Task.FromResult((IActionResult)Ok(products));
        }

        /// <summary>
        /// action method to create new product
        /// </summary>
        /// <param name="prod"></param>
        /// <returns></returns>

        [HttpPost]
        public Task<IActionResult> AddProduct(Product prod)
        {
            this._repository.Add(prod);

            return Task.FromResult((IActionResult)Ok(prod));
        }
    }
}
